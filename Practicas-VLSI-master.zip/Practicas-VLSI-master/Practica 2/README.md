# Práctica #2

_Registro de corrimiento que toma permite el cambio de direccionamiento, así como un reinicio._

## Demostración en YouTube 🚀

[YouTube](https://youtu.be/sCOXDK1RYGc) - Funcionamiento y simulación

### Instalación 🔧

_Se utilizó una tarjeta ARROW MAX 1000 en la implementación de esta solución. Encuentra en este repositorio el archivo .vhd que contiene el código fuente en VHDL._


## Autores ✒️

* **Andrés Uriel Chavira Tapia** - [urieltapia](https://github.com/urieltapia)
* **Jehosua Alan Joya Venegas** - [Jehosua97](https://github.com/Jehosua97)

También puedes mirar la lista de todos los [contribuyentes](https://github.com/Jehosua97/Practicas-VLSI/contributors) que han participado en este proyecto. 